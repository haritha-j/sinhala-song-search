class Splitter:
    def __init__(self):
        pass

    def split(self, text):
        raise NotImplementedError
