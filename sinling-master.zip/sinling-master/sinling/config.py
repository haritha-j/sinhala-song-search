from os.path import dirname, abspath, join

PROJECT_PATH = join(dirname(abspath(__file__)), '..')

BIN_PATH = join(PROJECT_PATH, 'bin')
